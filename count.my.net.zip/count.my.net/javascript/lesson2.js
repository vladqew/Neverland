const buttons = document.querySelectorAll('.btn')
var number = 0
const handleClick = (event) => {
    console.log( "target >" , event.target)
    console.log("curTarget" ,event.currentTarget)
    console.log(event.target === event.currentTarget)
    event.stopPropagation() // stopPropagation() метод який не дає батьківським елементам виконати функцію
}
//target це елемент на який ми нажали , а currentTarget це елемент який виконує обробляє подію


window.addEventListener('click' , () => {
    number++
    console.log('Window Click!')
    if (number == 10){
        console.log('Стоп')
        number = 0
    }
})


buttons.forEach(button => {
    button.addEventListener('click' , handleClick)
})


const img = document.querySelector('img')
img.addEventListener('mouseover' , function(event) {
    console.log(event.currentTarget)
    console.log(this)
})
img.addEventListener('click', (e) => {
    console.log('Джек Спарл')
    e.stopPropagation()
})
